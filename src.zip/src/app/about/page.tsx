import Image from "next/image"

export default function About() {
  return (
    <div className="grid md:grid-cols-2 gap-10 items-center">
      <Image src="/ingrid.jpg" alt="Ingrid Engström" width={500} height={600} className="rounded-2xl shadow-lg" />
      <div>
        <h2 className="text-3xl font-bold mb-4">Om SustainTech4Good AB</h2>
        <p className="mb-4 text-gray-700">
          SustainTech4Good AB erbjuder strategisk rådgivning inom industriell omställning och klimatstrategi för 
          tillverkande företag som vill nå sina hållbarhetsmål. 
        </p>
        <p className="mb-4 text-gray-700">
          Företaget grundades av Ingrid Engström, med över 30 års erfarenhet inom industri och ledarskap. 
          Kombinationen av teknisk förståelse och hållbarhetsexpertis gör att rekommendationerna blir både 
          genomförbara och lönsamma.
        </p>
        <p className="text-gray-700">
          Visionen är att bidra till en klimatneutral svensk industri med bibehållen konkurrenskraft.
        </p>
      </div>
    </div>
  )
}
