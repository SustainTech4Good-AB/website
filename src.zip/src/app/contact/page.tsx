import { Mail, Linkedin } from "lucide-react"
import Link from "next/link"

export default function Contact() {
  return (
    <div className="max-w-xl mx-auto bg-white rounded-2xl shadow-lg p-10 text-center">
      <h2 className="text-4xl font-bold mb-6 text-green-800">Kontakta mig</h2>
      <p className="text-gray-700 mb-6 text-lg leading-relaxed">
        Har du frågor eller vill diskutera ett samarbete? Du är varmt välkommen att höra av dig.
      </p>

      <div className="flex flex-col items-center space-y-3 mb-8">
        <div className="flex items-center space-x-2">
          <Mail className="text-green-700" size={20} />
          <a href="mailto:info@stfgab.se" className="text-green-700 font-medium hover:underline text-lg">
            info@stfgab.se
          </a>
        </div>
        <div className="flex items-center space-x-2">
          <Linkedin className="text-green-700" size={20} />
          <Link href="https://www.linkedin.com" target="_blank" className="text-green-700 font-medium hover:underline text-lg">
            LinkedIn
          </Link>
        </div>
      </div>

      <p className="text-sm text-gray-500">
        SustainTech4Good AB · Organisationsnummer 559549-1761
      </p>
    </div>
  )
}
