import Image from "next/image"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Home() {
  return (
    <section className="relative">
      <div className="relative w-full h-[70vh]">
        <Image src="/hero.jpg" alt="Rapsfält" fill priority className="object-cover brightness-[0.75]" />
        <div className="absolute inset-0 flex flex-col justify-center items-center text-center text-white px-6">
          <h1 className="text-5xl md:text-6xl font-bold drop-shadow-lg mb-4">
            Industriell omställning med klimatet i fokus
          </h1>
          <p className="max-w-2xl text-lg mb-8 opacity-90">
            SustainTech4Good AB hjälper tillverkande företag att nå klimatneutralitet 
            genom analys, rådgivning och projektledning.
          </p>
          <Button asChild size="lg" className="rounded-full bg-green-700 hover:bg-green-800 px-8 py-6 text-lg">
            <Link href="/contact">Kontakta mig</Link>
          </Button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto text-center mt-20">
        <h2 className="text-3xl font-bold mb-4 text-green-800">Teknik · Strategi · Hållbarhet</h2>
        <p className="text-lg text-gray-700 leading-relaxed">
          Jag erbjuder strategisk rådgivning inom industriell omställning och klimatstrategi för tillverkande företag
          som vill nå sina hållbarhetsmål. Genom datadriven analys och erfarenhet från industrin skapas praktiskt
          genomförbara färdplaner mot klimatneutralitet.
        </p>
      </div>
    </section>
  )
}
