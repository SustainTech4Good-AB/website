import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Leaf, Factory, Briefcase } from "lucide-react"

const services = [
  {
    title: "Klimatstrategi & färdplaner",
    desc: "Hjälp att skapa konkreta vägar mot klimatneutralitet genom analys, rådgivning och ledning.",
    icon: Leaf,
  },
  {
    title: "CCUS & energianalys",
    desc: "Tekniska och ekonomiska analyser för CO₂-infångning, energieffektivisering och processoptimering.",
    icon: Factory,
  },
  {
    title: "Projektledning & interim",
    desc: "Tillfällig ledningskompetens inom hållbarhet och teknik, baserat på över 30 års erfarenhet.",
    icon: Briefcase,
  },
]

export default function Services() {
  return (
    <div className="grid md:grid-cols-3 gap-8">
      {services.map((s) => (
        <Card key={s.title} className="p-4 shadow-md hover:shadow-xl transition-all duration-300 rounded-2xl">
          <CardHeader className="flex flex-col items-center text-center">
            <s.icon className="text-green-700 mb-3" size={40} />
            <CardTitle className="text-xl font-semibold">{s.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 text-center">{s.desc}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
