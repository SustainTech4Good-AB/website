export function Footer() {
  return (
    <footer className="border-t py-6 text-center text-sm text-gray-600">
      © {new Date().getFullYear()} SustainTech4Good AB – Org.nr 559549-1761 – www.stfgab.se
    </footer>
  )
}
