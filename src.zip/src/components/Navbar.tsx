"use client"
import Link from "next/link"
import Image from "next/image"

export function Navbar() {
  return (
    <nav className="bg-white/90 backdrop-blur border-b sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto flex justify-between items-center py-3 px-6">
        <Link href="/" className="flex items-center space-x-2 hover:opacity-90 transition">
          <Image src="/logo.png" alt="SustainTech4Good AB" width={40} height={40} />
          <span className="font-bold text-lg text-green-800">SustainTech4Good AB</span>
        </Link>
        <div className="space-x-6 text-sm font-medium">
          <Link href="/about" className="hover:text-green-800 transition">Om oss</Link>
          <Link href="/services" className="hover:text-green-800 transition">Tjänster</Link>
          <Link href="/contact" className="hover:text-green-800 transition">Kontakt</Link>
        </div>
      </div>
    </nav>
  )
}
